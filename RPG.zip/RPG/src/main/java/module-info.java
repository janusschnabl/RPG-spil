module com.mycompany.rpg {
    requires javafx.controls;
    requires javafx.fxml;
    requires java.base;

    opens com.mycompany.rpg to javafx.fxml;
    exports com.mycompany.rpg;
}
